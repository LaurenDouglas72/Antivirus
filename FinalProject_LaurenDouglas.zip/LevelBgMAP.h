
//{{BLOCK(LevelBgMAP)

//======================================================================
//
//	LevelBgMAP, 512x160@16, 
//	+ bitmap not compressed
//	Total size: 163840 = 163840
//
//	Time-stamp: 2017-04-10, 11:00:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVELBGMAP_H
#define GRIT_LEVELBGMAP_H

#define LevelBgMAPBitmapLen 163840
extern const unsigned short LevelBgMAPBitmap[81920];

#endif // GRIT_LEVELBGMAP_H

//}}BLOCK(LevelBgMAP)
