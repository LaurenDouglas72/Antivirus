#define NUMBULLETS 10
#define NUMENEMIES 10

#define SHIFTUP(i) ((i) << 8)
#define SHIFTDOWN(i) ((i) >> 8)

#define ROWMASK 0xFF
#define COLMASK 0x1FF

void goToStart();
void updateStart();
void updatePlayerGame();
void updatePlayerStart();
void hideSprites();
void goToGamefromStart();
void updateGame();
void initializePlayer();
void updateLose();
void goToLose();
void updateWin();
void goToWin();
void updateInstruct();
void goToInstruct();
void updatePause();
void goToPause();
void goToGamefromPause();
void initializeBullets();
void updateBullets();
void initializeEnemies();
void updateEnemies();
void updateScreenLocations();
void updateScore();
void updateLives();
void updateCheat();
void initializeCheat();
void goToNextLevel();
void updateNextLevel();
void updatePlayerNextLevel();
void initializePlayerNextLevel();
void updateLife();
void initializeLife();
void initializePlayerGame();
void updateBarrier();
void initializeBarrier();
void goToLevelTwo();
void initializePlayerLevelTwo();
void updateLevelTwo();
void initializeEnemiesLevel2();
void initializeCover();
void updateCover();
void updateBossLevel();
void goToBossLevel();
void updateBoss();
void initializeBoss();
void initializeBossEnemies();

typedef struct {
	int height;
	int width;
	int rdel;
	int cdel;
	int row;
	int col;
	int dead;
	int livesLost;
	int hit;
	int spriteAttr;
	int racc;
	int stopRange;
	int maxVSpeed;
	int maxHSpeed;
	int worldCol;
	int worldRow;
	int oldRow;
	int grounded;
	int invincible;
	int hurt;
	int lastLivesLost;
} PLAYER;

typedef struct {
	int height;
	int width;
	int rd;
	int cd;
	int row;
	int col;
	int active;
	int hide;
	int way;
	int hurt;
} BULLET;

typedef struct {
	int height;
	int width;
	int rd;
	int cd;
	int row;
	int col;
	int spriteAttr;
	int timer;
	int active;
	int hide;
	int hit;
	int used;
	int hitplayer;
	int hurt;
	int dead;
} ENEMY;

typedef struct {
	int height;
	int width;
	int row;
	int col;
	int worldCol;
	int active;
	int hide;
	int hit;
	int hitplayer;
	int spriteAttr;
} SPRITE;