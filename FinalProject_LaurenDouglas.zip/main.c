#include "main.h"
#include "myLib.h"
#include "Bg1.h"
#include "Sprites.h"
#include "LevelBg.h"
#include "Lose.h"
#include "Win.h"
#include "Instruct.h"
#include "Bg1MAP.h"
#include "Pause.h"
#include "update.h"
#include "LevelBgMAP.h"
#include "sound.h"
#include "maintheme.h"
#include "ShootingSound.h"
#include "Bg1Other.h"
#include "LeftHook.h"
#include "Dying.h"
#include "Game.h"
#include "winning.h"
#include "Roar.h"
#include "ending.h"
#include "getLife.h"
#include "electricshock.h"
#include "Level2Bg.h"
#include "Level2BgMAP.h"
#include <stdlib.h>
#include "Boss.h"
#include "BossMAP.h"

/*
I'm making a game where you have to dodge enemies and shoot them. You progress
from level to level killing enemies until you defeat a boss. 

In my game I have all my states implemented and one level. 
There are enemies that you have to kill to in order to win, and I have
pooling set up for the bullets. The aliens are also set up with an array of 
structs, and collision works for them. Right now they're set up so that
if they hit you once, they can't hurt you a second time so that you aren't killed
immediately upon impact. I have gravity working, and scrolling 
of the background in the start screen. All the sound works. The enemies follow you around
wherever you go. The cheat is also set up and is
hidden on the start screen. You jump over the door on a hidden
platform and get a pill that makes you invincible. All the art is pretty much done.
From here I want to work on making the game play harder, right now the enemies just come out 
of one location which means that if you stand in one spot you can just kill them in one go.
I also want to implement more levels and a boss level at the end. 
*/

unsigned int buttons;
unsigned int oldButtons;
//state machine enum
enum{START, INSTRUCT, GAME, LOSE, PAUSE, WIN, NEXTLEVEL, LEVELTWO, BOSSLEVEL};
enum{RIGHT, LEFT};
enum{PLYR, BLTS, LVS = 3 + NUMBULLETS, SCORE = 4 + NUMBULLETS + 4,
		CHT = 5 + NUMBULLETS + 22, LF = 6 + NUMBULLETS + 22, PS = 7 + NUMBULLETS + 22,
		BR = 9 + NUMBULLETS + 22, LVS2 = 10 + NUMBULLETS + 31, BS = 11 + NUMBULLETS + 36, ENM = 12 + NUMBULLETS + 41,
		BSSCORE = 13 + NUMBULLETS + NUMENEMIES + 41, BENM = 20 + NUMBULLETS + NUMENEMIES + 41};

OBJ_ATTR shadowOAM[128];

int state;
PLAYER player;
BULLET bullets[NUMBULLETS];
ENEMY enemies[NUMENEMIES];
ENEMY bossEnemies[4];
SPRITE cheat;
SPRITE life;
SPRITE barrier1;
SPRITE barrier2;
SPRITE cover;
ENEMY boss;

int hOffBg;
int vOff;
//these are the timers to animate the barriers (electric fields)
int bartimer;
int bartimer2;
int vOff;
int hOff;
int timeSinceLast;
int timer;
int lives;
int score;
int enemiesLeft;
int level;
int seed;
int bosstimer;
int bosstimer2;
int fightmonst;

int ghost_blend;
int counter;
int changeBlending;

int main() {
	goToStart();

	//sets up sounds
	setupSounds();
	setupInterrupts();

	//sets the sound with the correct main theme that loops
	playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);

	while(1) {
		oldButtons = buttons;
		buttons = BUTTONS;

		//state machine
		switch(state) {
			case GAME:
				updateGame();
				break;
			case LOSE:
				updateLose();
				break;
			case START:
				updateStart();
				break;
			case INSTRUCT:
				updateInstruct();
				break;
			case PAUSE:
				updatePause();
				break;
			case WIN:
				updateWin();
				break;
			case NEXTLEVEL:
				updateNextLevel();
				break;
			case LEVELTWO:
				updateLevelTwo();
				break;
			case BOSSLEVEL:
				updateBossLevel();
				break;
		}
	}
}

//goes to start
void goToStart() {
	state = START;

	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE1 | CBB(0);
	REG_BG1CNT = SBB(28) | BG_SIZE1 | CBB(1);
	
	hOffBg = 0;
	vOff = 0;
	hOff = 0;
	REG_BG0HOFS = hOff;
	enemiesLeft = 0;

	//loads the backgrounds - BG1 Scrolling
	loadPalette(Bg1Pal);
    DMANow(3, Bg1Tiles, &CHARBLOCKBASE[0], Bg1TilesLen/2);
    DMANow(3, Bg1Map, &SCREENBLOCKBASE[30], Bg1MapLen/2);

    DMANow(3, Bg1OtherTiles, &CHARBLOCKBASE[1], Bg1OtherTilesLen/2);
    DMANow(3, Bg1OtherMap, &SCREENBLOCKBASE[28], Bg1OtherMapLen/2);
	
	//resets everything
	//this is used to reset the player cheat
	player.invincible = 0;
	level = 0;

    initializePlayer();
    initializeBullets();
    initializeCheat();
    updateScore();
}

//updates start
void updateStart() {
	DMANow(3, shadowOAM, OAM, 512);
	shadowOAM[PS].attr0 = ATTR0_HIDE;
	shadowOAM[PS + 1].attr0 = ATTR0_HIDE;

	//scrolls BG1 in proportion to the player
	if(BUTTON_HELD(BUTTON_RIGHT) && hOff > 0 && hOff < (512 - 240)) {
		hOffBg+=2;
	} else if (BUTTON_HELD(BUTTON_LEFT) && hOff > 0 && hOff < (512 - 240)) {
		hOffBg-=2;
	}
	++hOffBg;
	REG_BG1HOFS = (++hOffBg);

	//this makes the sprite for the cheat show up only when it's on the screen
	cheat.col = cheat.worldCol - hOff;
	cheat.hide = (cheat.col < -cheat.width || cheat.col > 240) ? 1 : 0;

	//updates everything
	updatePlayerStart();
	updateBullets();
	updateCheat();
	waitForVblank();

	//if you hit select you go to instructions
	//to get to game you go into the door - this is coded in updatePlayerStart()
	if (BUTTON_PRESSED(BUTTON_SELECT)) {
		goToInstruct();
	}
}

//goes to instructions
void goToInstruct() {
	REG_DISPCTL = MODE0 | BG0_ENABLE;
	REG_BG0CNT = SBB(25) | BG_SIZE2 | CBB(0);
	
	hOffBg = 0;
	vOff = 0;
	hOff = 0;
	REG_BG0HOFS = hOff;
	state = INSTRUCT;

	loadPalette(InstructPal);
    DMANow(3, InstructTiles, &CHARBLOCKBASE[0], InstructTilesLen/2);
    DMANow(3, InstructMap, &SCREENBLOCKBASE[25], InstructMapLen/2);
}

//updates instructions
void updateInstruct() {
	//implements scrolling for the instructions
	if(BUTTON_HELD(BUTTON_UP)) {
		if(vOff > 0) {
			vOff--;
		}
	}
	if(BUTTON_HELD(BUTTON_DOWN)) {
		if(vOff < (512 - 160)) {
			vOff++;
		}
	}
	//pressing start goes back to start
	if(BUTTON_PRESSED(BUTTON_START)) {
		goToStart();
	}
	waitForVblank();
	REG_BG0VOFS = (vOff);
}

//goes to the game from start screen 
//needed a different way to go to game from pause
//so that pause could keep track of everything to keep it the same
void goToGamefromStart() {
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE1 | CBB(0);
	REG_BG1CNT = SBB(28) | BG_SIZE1 | CBB(1);
	hOffBg = 0;

	srand(++seed);

	vOff = 0;
	hOff = 0;
	player.col = 100;
	cheat.active = 0;
	updateCheat();

	enemiesLeft = NUMENEMIES;
	state = GAME;

	loadPalette(LevelBgPal);
    DMANow(3, LevelBgTiles, &CHARBLOCKBASE[0], LevelBgTilesLen/2);
    DMANow(3, LevelBgMap, &SCREENBLOCKBASE[30], LevelBgMapLen/2);

    DMANow(3, Bg1OtherTiles, &CHARBLOCKBASE[1], Bg1OtherTilesLen/2);
    DMANow(3, Bg1OtherMap, &SCREENBLOCKBASE[28], Bg1OtherMapLen/2);
    initializePlayerGame();
    initializeBullets();
    initializeEnemies();
    initializeBarrier();
    level = 0;
}

//updates the game
void updateGame() {
	DMANow(3, shadowOAM, OAM, 512);
	shadowOAM[PS].attr0 = ATTR0_HIDE;
	shadowOAM[PS + 1].attr0 = ATTR0_HIDE;

	//this updates everything
	updatePlayerGame();
	updateBullets();
	updateEnemies();
	updateBarrier();
	waitForVblank();

	//This scrolls the background
	++hOffBg;
	REG_BG1HOFS = (++hOffBg);

	//if you die go to lose
	//die from hitting an enemy 3 times
	if(player.dead) {
		goToLose();
	}
	//this calculates how many enemies you've gotten
	int numgot = 0;
	for(int i = 0; i < NUMENEMIES; i++) {
		if(enemies[i].dead == 1) {
			numgot++;
		}
	}
	//once you've gotten all the enemies, go to win
	if(numgot == NUMENEMIES) {
		barrier1.active = 0;
		barrier2.active = 0;
		goToNextLevel();
	}
	//press start to pause
	if(BUTTON_PRESSED(BUTTON_START)) {
		hOff = 0;
		goToPause();
	}

	REG_BG0HOFS = 0;
}

//goes to pause
void goToPause() {
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
	
	REG_BLDMOD = 0;
	state = PAUSE;
	playSoundA(Game, GAMELEN, GAMEFREQ, 1);
}

//updates pause
void updatePause() {
	DMANow(3, shadowOAM, OAM, 512);
	//if you press start go back to game
	//if you press select then restart level
	if(BUTTON_PRESSED(BUTTON_START)) {
		if(level == 0) {
			goToGamefromPause();
		} else if (level == 1) {
			playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
			state = LEVELTWO;
		} else if (level == 2) {
			playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
			state = BOSSLEVEL;
		}
	}
	if(BUTTON_PRESSED(BUTTON_SELECT)) {
		//sets the sound with the correct main theme that loops
		playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
		if(level == 0) {
			goToGamefromStart();
		} else if (level == 1) {
			goToLevelTwo();
		} else if(level == 2) {
			goToBossLevel();
		}
	}
	if(BUTTON_PRESSED(BUTTON_B)) {
		playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
		goToStart();
	}

	//sets up a sprite for the pause instructions
	shadowOAM[PS].attr0 = 50;
	shadowOAM[PS].attr1 = 55 | ATTR1_SIZE64;
	shadowOAM[PS].attr2 = SPRITEOFFSET16(10, 0);
	shadowOAM[PS + 1].attr0 = 50;
	shadowOAM[PS + 1].attr1 = 119 | ATTR1_SIZE64;
	shadowOAM[PS + 1].attr2 = SPRITEOFFSET16(10, 8);

	REG_BG0HOFS = 0;
	REG_BG1HOFS = (hOffBg);
}

//this goes to the game from the pause state
void goToGamefromPause() {
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE1 | CBB(0);
	REG_BG1CNT = SBB(28) | BG_SIZE1 | CBB(1);
	state = GAME;
	srand(++seed);
	playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);

	loadPalette(LevelBgPal);
    DMANow(3, LevelBgTiles, &CHARBLOCKBASE[0], LevelBgTilesLen/2);
    DMANow(3, LevelBgMap, &SCREENBLOCKBASE[30], LevelBgMapLen/2);

    DMANow(3, Bg1OtherTiles, &CHARBLOCKBASE[1], Bg1OtherTilesLen/2);
    DMANow(3, Bg1OtherMap, &SCREENBLOCKBASE[28], Bg1OtherMapLen/2);
}

//this goes to lose if you die
void goToLose() {
	REG_DISPCTL = MODE0 | BG0_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE0 | CBB(0);
	vOff = 0;
	hOff = 0;

	playSoundA(Dying, DYINGLEN, DYINGFREQ, 0);

	state = LOSE;

	loadPalette(LosePal);
    DMANow(3, LoseTiles, &CHARBLOCKBASE[0], LoseTilesLen/2);
    DMANow(3, LoseMap, &SCREENBLOCKBASE[30], LoseMapLen/2);
}

//updates lose
void updateLose() {
	if(BUTTON_PRESSED(BUTTON_START)) {
		playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
		goToStart();
	}
}

//goes to win 
void goToWin() {
	// REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER2;
	// loadPalette(Win2Pal);
	REG_DISPCTL = MODE0 | BG0_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE0 | CBB(0);
	vOff = 0;
	hOff = 0;
	playSoundA(_ending, _ENDINGLEN, _ENDINGFREQ, 1);
	state = WIN;

	loadPalette(WinPal);
    DMANow(3, WinTiles, &CHARBLOCKBASE[0], WinTilesLen/2);
    DMANow(3, WinMap, &SCREENBLOCKBASE[30], WinMapLen/2);
}

//updates win
void updateWin() {
	if(BUTTON_PRESSED(BUTTON_START)) {
		playSoundA(maintheme, MAINTHEMELEN, MAINTHEMEFREQ, 1);
		goToStart();
	}
}

//goes to the next level
void goToNextLevel() {
	state = NEXTLEVEL;
	enemiesLeft = 0;
	player.lastLivesLost = player.livesLost;
	boss.active = 0;
	initializePlayerNextLevel();
	initializeLife();
	player.livesLost = player.lastLivesLost;
	updateBarrier();
	updateBoss();
	updateEnemies();
	playSoundB(winning, WINNINGLEN, WINNINGFREQ, 0);

	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | SPRITE_ENABLE;
	REG_BG0CNT = SBB(30) | BG_SIZE1 | CBB(0);
	REG_BG1CNT = SBB(28) | BG_SIZE1 | CBB(1);
	
	REG_BLDMOD = 0;
}

//updates the next level
void updateNextLevel() {
	DMANow(3, shadowOAM, OAM, 512);

	//makes it so that the life sprite is only on the screen when it's supposed to be
	life.col = life.worldCol - hOff;
	life.hide = (life.col < -life.width || life.col > 240) ? 1 : 0;

	//scroll the background1
	if(BUTTON_HELD(BUTTON_RIGHT) && hOff > 0 && hOff < (512 - 240)) {
		hOffBg+=2;
	} else if (BUTTON_HELD(BUTTON_LEFT) && hOff > 0 && hOff < (512 - 240)) {
		hOffBg-=2;
	}
	++hOffBg;
	REG_BG1HOFS = (++hOffBg);

	updatePlayerNextLevel();
	updateBullets();
	updateLife();
	updateLives();
	waitForVblank();
}

void goToLevelTwo() {
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

	REG_BG0CNT = CBB(0) | SBB(30) | BG_SIZE1;
    REG_BG1CNT = CBB(1) | SBB(28) | BG_SIZE1;
    REG_BG2CNT = CBB(2) | SBB(26) | BG_SIZE1;

    //set up blending registers
    REG_BLDMOD = BG0_B | OBJ_B | BACKDROP_A | NORMAL_TRANS;
	player.lastLivesLost = player.livesLost;
	counter = 0;
	changeBlending = 5;
	ghost_blend = 16;
	
	hOffBg = 0;
	srand(++seed);
	vOff = 0;
	hOff = 0;
	player.col = 100;
	state = LEVELTWO;
	enemiesLeft = NUMENEMIES;

	player.livesLost = player.lastLivesLost;
	updateEnemies();
	
	loadPalette(Level2BgPal);
    DMANow(3, Level2BgTiles, &CHARBLOCKBASE[0], Level2BgTilesLen/2);
    DMANow(3, Level2BgMap, &SCREENBLOCKBASE[30], Level2BgMapLen/2);

    DMANow(3, Bg1OtherTiles, &CHARBLOCKBASE[1], Bg1OtherTilesLen/2);
    DMANow(3, Bg1OtherMap, &SCREENBLOCKBASE[28], Bg1OtherMapLen/2);

    DMANow(3, Level2BgTiles, &CHARBLOCKBASE[2], Level2BgTilesLen/2);
    DMANow(3, Level2BgMap, &SCREENBLOCKBASE[26], Level2BgMapLen/2);
	level = 1;

    initializePlayerLevelTwo();
    initializeBullets();
    initializeEnemiesLevel2();
    initializeBarrier();

    life.active = 0;
	updateLife();
	player.livesLost = player.lastLivesLost;
}

//updates the second level
void updateLevelTwo() {
	DMANow(3, shadowOAM, OAM, 512);
	shadowOAM[PS].attr0 = ATTR0_HIDE;
	shadowOAM[PS + 1].attr0 = ATTR0_HIDE;

	//this updates everything
	updatePlayerGame();
	updateBullets();
	updateEnemies();
	updateBarrier();
	waitForVblank();


	if(++counter % changeBlending == 0) {
    	ghost_blend--;
    }
    
    if(ghost_blend < 0) {
    	ghost_blend = 32; 
    }
    if(ghost_blend >= 16) {
		REG_COLV = WEIGHTOFA(ghost_blend - 16) | WEIGHTOFB(32 - ghost_blend);
    } else {
		REG_COLV = WEIGHTOFA(16 - ghost_blend) | WEIGHTOFB(ghost_blend);
    }
	
	
	//This scrolls the background
	++hOffBg;
	REG_BG1HOFS = (++hOffBg);

	//this calculates how many enemies you've gotten
	int numgot = 0;
	for(int i = 0; i < NUMENEMIES; i++) {
		if(enemies[i].dead == 1) {
			numgot++;
		}
	}
	//once you've gotten all the enemies, go to win
	if(numgot == NUMENEMIES) {
		barrier1.active = 0;
		barrier2.active = 0;
		level = 1;
		goToNextLevel();
	}
	//press start to pause
	if(BUTTON_PRESSED(BUTTON_START)) {
		hOff = 0;
		goToPause();
	}

	REG_BG0HOFS = 0;

	//if you die go to lose
	//die from hitting an enemy 3 times
	if(player.dead) {
		goToLose();
	}
}

void goToBossLevel() {
	REG_DISPCTL = MODE0 | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

	REG_BG0CNT = CBB(0) | SBB(30) | BG_SIZE1;
    REG_BG1CNT = CBB(1) | SBB(28) | BG_SIZE1;
    REG_BG2CNT = CBB(2) | SBB(26) | BG_SIZE1;

    //set up blending registers
    REG_BLDMOD = BG0_B | OBJ_B | BACKDROP_A | NORMAL_TRANS;
	player.lastLivesLost = player.livesLost;
	counter = 0;
	changeBlending = 5;
	ghost_blend = 16;
	
	hOffBg = 0;
	srand(++seed);
	vOff = 0;
	hOff = 0;
	player.col = 100;
	state = BOSSLEVEL;
	bosstimer = 0;
	bosstimer2 = 0;
	enemiesLeft = 0;
	//enemiesLeft = NUMENEMIES;

	player.livesLost = player.lastLivesLost;
	updateEnemies();

	loadPalette(BossPal);
    DMANow(3, BossTiles, &CHARBLOCKBASE[0], BossTilesLen/2);
    DMANow(3, BossMap, &SCREENBLOCKBASE[30], BossMapLen/2);

    DMANow(3, Bg1OtherTiles, &CHARBLOCKBASE[1], Bg1OtherTilesLen/2);
    DMANow(3, Bg1OtherMap, &SCREENBLOCKBASE[28], Bg1OtherMapLen/2);

    DMANow(3, BossTiles, &CHARBLOCKBASE[2], BossTilesLen/2);
    DMANow(3, BossMap, &SCREENBLOCKBASE[26], BossMapLen/2);
	level = 2;

    initializePlayerLevelTwo();
    initializeBullets();
    initializeBoss();
    initializeBossEnemies();
    initializeBarrier();
    boss.active = 1;
    boss.hit = 0;
    boss.hide = 0;

    life.active = 0;
	updateLife();
	player.livesLost = player.lastLivesLost;
}

void updateBossLevel() {
	DMANow(3, shadowOAM, OAM, 512);
	shadowOAM[PS].attr0 = ATTR0_HIDE;
	shadowOAM[PS + 1].attr0 = ATTR0_HIDE;

	if(++counter % changeBlending == 0) {
    	ghost_blend--;
    }
    
    if(ghost_blend < 0) {
    	ghost_blend = 32; 
    }
    if(ghost_blend >= 16) {
		REG_COLV = WEIGHTOFA(ghost_blend - 16) | WEIGHTOFB(32 - ghost_blend);
    } else {
		REG_COLV = WEIGHTOFA(16 - ghost_blend) | WEIGHTOFB(ghost_blend);
    }
	
	
	//This scrolls the background
	++hOffBg;
	REG_BG1HOFS = (++hOffBg);

	//this calculates how many enemies you've gotten
	int numgot = 0;
	for(int i = 0; i < 3; i++) {
		if(bossEnemies[i].hit == 1) {
			numgot++;
		}
	}

	//press start to pause
	if(BUTTON_PRESSED(BUTTON_START)) {
		hOff = 0;
		goToPause();
	}

	REG_BG0HOFS = 0;

	//if you die go to lose
	//die from hitting an enemy 3 times
	if(player.dead) {
		goToLose();
	}

	updateBoss();
	updatePlayerGame();
	updateBullets();
	updateBarrier();
	waitForVblank();

	if(!boss.active) {
		barrier1.active = 0;
		barrier2.active = 0;
		bossEnemies[0].active = 0;
		bossEnemies[1].active = 0;
		bossEnemies[2].active = 0;
		bossEnemies[0].hide = 1;
		bossEnemies[1].hide = 1;
		bossEnemies[2].hide = 1;
		boss.hurt = 0;
		updateBoss();
		goToNextLevel();
	}
}

void updateBoss() {
	if(player.livesLost > lives) {
		player.dead = 1;
	}

	if(boss.active && !boss.hide) {
		shadowOAM[BS].attr0 = boss.row;
		shadowOAM[BS].attr1 = boss.col | ATTR1_SIZE64;
		if(!fightmonst) {	
			if(boss.hurt < 1) {	
				if(boss.spriteAttr == LEFT) {
					shadowOAM[BS].attr2 = SPRITEOFFSET16(16, 16);
				} else {
					shadowOAM[BS].attr2 = SPRITEOFFSET16(16, 24);
				}
			} else if(boss.hurt > 0 && boss.hurt < 10) {
				shadowOAM[BS].attr2 = SPRITEOFFSET16(0, 24);
			}
		} else {
			if(boss.spriteAttr == LEFT) {
				shadowOAM[BS].attr2 = SPRITEOFFSET16(24, 4);
			} else {
				shadowOAM[BS].attr2 = SPRITEOFFSET16(24, 12);
			}
		}
	} else {
		shadowOAM[BS].attr0 = ATTR0_HIDE;
	}

	if(boss.hurt > 9) {
		boss.hurt = 0;
	} else if(boss.hurt > 0) {
		boss.hurt++;
	}

	if((!(timer % 15))) {
		if(boss.spriteAttr == LEFT) {
			boss.spriteAttr = RIGHT;
		} else {
			boss.spriteAttr = LEFT;
		}
	}
	timer++;

	for(int i = 0; i < NUMBULLETS; i++) {
		if(bullets[i].active && !bullets[i].hurt && boss.active) {
			int collisionCheck = genericCollision(
				bullets[i].row, bullets[i].col, bullets[i].width, bullets[i].height,
				boss.row + boss.rd, boss.col + boss.cd, boss.width, boss.height);
			if(collisionCheck != -1) {
				bullets[i].hurt = 1;
				if(!fightmonst) {	
					boss.hit++;
					boss.hurt = 1;
					playSoundB(Roar, ROARLEN, ROARFREQ, 0);
				}
			}
		}
	}

	if(player.livesLost > lives) {
		player.dead = 1;
	}

	if (boss.hit == 10) {
		boss.active = 0;
		boss.hide = 1;
		bossEnemies[0].active = 0;
		bossEnemies[1].active = 0;
		bossEnemies[2].active = 0;
		bossEnemies[0].hide = 1;
		bossEnemies[1].hide = 1;
		bossEnemies[2].hide = 1;
		boss.hurt = 0;
		enemiesLeft = 0;
		fightmonst = 0;
	}

	bosstimer++;
	timer++;

	if(boss.active && bosstimer2 == 200 && !bossEnemies[0].active && !bossEnemies[1].active && !bossEnemies[2].active) {
		initializeBossEnemies();
		bossEnemies[0].hurt = 0;
		bossEnemies[0].hide = 0;
		bossEnemies[0].active = 1;
		bossEnemies[0].col = 10;
		bossEnemies[1].hurt = 0;
		bossEnemies[1].hide = 0;
		bossEnemies[1].active = 1;
		bossEnemies[2].hurt = 0;
		bossEnemies[2].hide = 0;
		bossEnemies[2].active = 1;
		enemiesLeft = 3;
		fightmonst = 1;
		bosstimer2 = 0;
	}

	if(bossEnemies[0].active && !bossEnemies[0].hide) {
		if(!bossEnemies[0].hurt) {	
			shadowOAM[BENM].attr0 = bossEnemies[0].row | ATTR0_BLEND;
		} else {
			shadowOAM[BENM].attr0 = bossEnemies[0].row | ATTR0_NORMAL;
		}
		shadowOAM[BENM].attr1 = bossEnemies[0].col | ATTR1_SIZE16;
		if(!bossEnemies[0].hurt) {	
			if(bossEnemies[0].spriteAttr == LEFT) {
				shadowOAM[BENM].attr2 = SPRITEOFFSET16(6,0);
			} else {
				shadowOAM[BENM].attr2 = SPRITEOFFSET16(6,2);
			}
		} else if(bossEnemies[0].hurt == 1 || bossEnemies[0].hurt == 2) {
			shadowOAM[BENM].attr2 = SPRITEOFFSET16(6,7);
		} else if(bossEnemies[0].hurt == 3 || bossEnemies[0].hurt == 4) {
			shadowOAM[BENM].attr2 = SPRITEOFFSET16(6,9);
		} else if(bossEnemies[0].hurt == 5 || bossEnemies[0].hurt == 6) {
			shadowOAM[BENM].attr2 = SPRITEOFFSET16(6,11);
		}
		if(!bossEnemies[0].hurt) {
			if(bossEnemies[0].row != 142) {
				bossEnemies[0].row++;
			} else {
				//this gets the enemies to follow the player
				if((bossEnemies[0].col + bossEnemies[0].width) < player.col) {
					
					if(bossEnemies[0].cd < 0) {
						bossEnemies[0].cd = -bossEnemies[0].cd;
					}
					
				} else if (bossEnemies[0].col > (player.col + player.width)) {
					if(bossEnemies[0].cd > 0) {
						bossEnemies[0].cd = -bossEnemies[0].cd;
					}
				}
				//keeps the enemeies on the screen
				if(bossEnemies[0].col < 1) {
						bossEnemies[0].col = 1;
				} else if (bossEnemies[0].col > 240 - bossEnemies[0].width) {
					bossEnemies[0].col = 240 - bossEnemies[0].width;
				}
				bossEnemies[0].col += bossEnemies[0].cd;

				//animates the enemies
				if((!(timer % 15))) {
					if(bossEnemies[0].spriteAttr == LEFT) {
						bossEnemies[0].spriteAttr = RIGHT;
					} else {
						bossEnemies[0].spriteAttr = LEFT;
					}
				}
			}
		}
	} else if((!bossEnemies[0].active && !bossEnemies[0].hide) || bossEnemies[0].hurt == 7) {
		shadowOAM[BENM].attr0 = ATTR0_HIDE;
		bossEnemies[0].hide = 1;
	}

	if(bossEnemies[1].active && !bossEnemies[1].hide) {
		shadowOAM[BENM + 1].attr0 = bossEnemies[1].row;
		shadowOAM[BENM + 1].attr1 = ATTR1_SIZE16 | bossEnemies[1].col;
		if(!bossEnemies[1].hurt) {	
			if(bossEnemies[1].spriteAttr == LEFT) {
				shadowOAM[1 + BENM].attr2 = SPRITEOFFSET16(4,0);
			} else {
				shadowOAM[1 + BENM].attr2 = SPRITEOFFSET16(4,2);
			}
		} else if(bossEnemies[1].hurt == 1 || bossEnemies[1].hurt == 2) {
			shadowOAM[1 + BENM].attr2 = SPRITEOFFSET16(4,7);
		} else if(bossEnemies[1].hurt == 3 || bossEnemies[1].hurt == 4) {
			shadowOAM[1 + BENM].attr2 = SPRITEOFFSET16(4,9);
		} else if(bossEnemies[1].hurt == 5 || bossEnemies[1].hurt == 6) {
			shadowOAM[1 + BENM].attr2 = SPRITEOFFSET16(4,11);
		}
		if(!bossEnemies[1].hurt) {
			if(bossEnemies[1].row != 142) {
				bossEnemies[1].row++;
			} else {
				//this gets the enemies to follow the player
				if((bossEnemies[1].col + bossEnemies[1].width) < player.col) {
					
					if(bossEnemies[1].cd < 0) {
						bossEnemies[1].cd = -bossEnemies[1].cd;
					}
					
				} else if (bossEnemies[1].col > (player.col + player.width)) {
					if(bossEnemies[1].cd > 0) {
						bossEnemies[1].cd = -bossEnemies[1].cd;
					}
				}
				//keeps the enemeies on the screen
				if(bossEnemies[1].col < 1) {
						bossEnemies[1].col = 1;
				} else if (bossEnemies[1].col > 240 - bossEnemies[1].width) {
					bossEnemies[1].col = 240 - bossEnemies[1].width;
				}
				bossEnemies[1].col += bossEnemies[1].cd;

				//animates the enemies
				if((!(timer % 15))) {
					if(bossEnemies[1].spriteAttr == LEFT) {
						bossEnemies[1].spriteAttr = RIGHT;
					} else {
						bossEnemies[1].spriteAttr = LEFT;
					}
				}
			}
		}
	} else if((!bossEnemies[1].active && !bossEnemies[1].hide) || bossEnemies[1].hurt == 7) {
		shadowOAM[BENM + 1].attr0 = ATTR0_HIDE;
		bossEnemies[1].hide = 1;
	}

	if(bossEnemies[2].active && !bossEnemies[2].hide) {
		if(!bossEnemies[2].hurt) {	
			shadowOAM[BENM + 2].attr0 = bossEnemies[2].row | ATTR0_BLEND;
		} else {
			shadowOAM[BENM + 2].attr0 = bossEnemies[2].row | ATTR0_NORMAL;
		}
		shadowOAM[BENM + 2].attr1 = ATTR1_SIZE16 | bossEnemies[2].col;
		if(!bossEnemies[2].hurt) {	
			if(bossEnemies[2].spriteAttr == LEFT) {
				shadowOAM[2 + BENM].attr2 = SPRITEOFFSET16(6,0);
			} else {
				shadowOAM[2 + BENM].attr2 = SPRITEOFFSET16(6,2);
			}
		} else if(bossEnemies[2].hurt == 1 || bossEnemies[2].hurt == 2) {
			shadowOAM[2 + BENM].attr2 = SPRITEOFFSET16(6,7);
		} else if(bossEnemies[2].hurt == 3 || bossEnemies[2].hurt == 4) {
			shadowOAM[2 + BENM].attr2 = SPRITEOFFSET16(6,9);
		} else if(bossEnemies[2].hurt == 5 || bossEnemies[2].hurt == 6) {
			shadowOAM[2 + BENM].attr2 = SPRITEOFFSET16(6,11);
		}
		if(!bossEnemies[2].hurt) {
			if(bossEnemies[2].row != 142) {
				bossEnemies[2].row++;
			} else {
				//this gets the enemies to follow the player
				if((bossEnemies[2].col + bossEnemies[2].width) < player.col) {
					
					if(bossEnemies[2].cd < 0) {
						bossEnemies[2].cd = -bossEnemies[2].cd;
					}
					
				} else if (bossEnemies[2].col > (player.col + player.width)) {
					if(bossEnemies[2].cd > 0) {
						bossEnemies[2].cd = -bossEnemies[2].cd;
					}
				}
				//keeps the enemeies on the screen
				if(bossEnemies[2].col < 1) {
						bossEnemies[2].col = 1;
				} else if (bossEnemies[2].col > 240 - bossEnemies[2].width) {
					bossEnemies[2].col = 240 - bossEnemies[2].width;
				}
				bossEnemies[2].col += bossEnemies[2].cd;

				//animates the enemies
				if((!(timer % 15))) {
					if(bossEnemies[2].spriteAttr == LEFT) {
						bossEnemies[2].spriteAttr = RIGHT;
					} else {
						bossEnemies[2].spriteAttr = LEFT;
					}
				}
			}
		}
	} else if((!bossEnemies[2].active && !bossEnemies[2].hide) || bossEnemies[2].hurt == 7) {
		shadowOAM[BENM + 2].attr0 = ATTR0_HIDE;
		bossEnemies[2].hide = 1;
	}

	if(enemiesLeft == 0) {
		fightmonst = 0;
		bosstimer2++;
	}
	//goes through the enemies and the bullets to see if the enemies have been hit
	//if they are incremet score
	for(int i = 0; i < NUMBULLETS; i++) {
		for (int j = 0; j < 3; j++) {
			if(bullets[i].active && !bullets[i].hurt && bossEnemies[j].active && !bossEnemies[j].hit) {
				int collisionCheck = genericCollision(
					bullets[i].row, bullets[i].col, bullets[i].width, bullets[i].height,
					bossEnemies[j].row + bossEnemies[j].rd, bossEnemies[j].col + bossEnemies[j].cd, bossEnemies[j].width, bossEnemies[j].height);
				if(collisionCheck != -1) {
					bossEnemies[j].hit = 1;
					bossEnemies[j].hurt = 1;
					bullets[i].hurt = 1;
					enemiesLeft--;
				}
			}
		}
	}

	if(bossEnemies[0].hurt > 0) {
		shadowOAM[BENM].attr0 = bossEnemies[0].row | ATTR0_NORMAL;
	}
	if(bossEnemies[2].hurt > 0) {
		shadowOAM[BENM + 2].attr0 = bossEnemies[2].row | ATTR0_NORMAL;
	}

	for (int j = 0; j < 3; j++) {
		if(bossEnemies[j].hurt > 0 && bossEnemies[j].hurt < 7) {
			bossEnemies[j].hurt++;
		} else if(bossEnemies[j].hurt == 7) {
			bossEnemies[j].hurt = 0;
			bossEnemies[j].active = 0;
		}
	}

	//goes through the enemies and sees if they've hit the player
	//if they have then currently they can't hit the player again
	//also decrease the lives
	//only does this if the player isn't invincible
	if(!player.invincible) {
		for(int i = 0; i < 3; i++) {
			if(bossEnemies[i].active && !(bossEnemies[i].hitplayer)) {
				int collisionCheck = genericCollision(
					SHIFTDOWN(player.row), player.col, player.width, player.height,
					bossEnemies[i].row + bossEnemies[i].rd, bossEnemies[i].col + bossEnemies[i].cd, bossEnemies[i].width, bossEnemies[i].height);
				if(collisionCheck != -1) {
					player.livesLost++;
					player.hurt = 1;
					bossEnemies[i].hitplayer = 1;
					bossEnemies[i].hit = 1;
					bossEnemies[i].hurt = 1;
					enemiesLeft--;
					playSoundB(LeftHook, LEFTHOOKLEN, LEFTHOOKFREQ, 0);
				}
			}
		}
	}
}

//updates the enemies
void updateEnemies() {
	for(int i = 0; i < NUMENEMIES; i++) {
		//only shows the enemies if they are active and not hidden
		if(enemies[i].active && !(enemies[i].hide)) {
			shadowOAM[i+ENM].attr0 = enemies[i].row;
			shadowOAM[i+ENM].attr1 = ATTR1_SIZE16 | enemies[i].col;
			//animates the enemies
			if(level == 0) {
				if(!enemies[i].hurt) {
					if(enemies[i].spriteAttr == LEFT) {
						shadowOAM[i+ENM].attr2 = SPRITEOFFSET16(4,0);
					} else {
						shadowOAM[i+ENM].attr2 = SPRITEOFFSET16(4,2);
					}
				} else if(enemies[i].hurt == 1 || enemies[i].hurt == 2) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(4,7);
				} else if(enemies[i].hurt == 3 || enemies[i].hurt == 4) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(4,9);
				} else if(enemies[i].hurt == 5 || enemies[i].hurt == 6) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(4,11);
				}
			} else if(level == 1) {
				shadowOAM[i+ENM].attr0 = enemies[i].row | ATTR0_BLEND;
				if(!enemies[i].hurt) {
					if(enemies[i].cd < 0) {
						shadowOAM[i+ENM].attr2 = (SPRITEOFFSET16(6,0));
					} else {
						shadowOAM[i+ENM].attr2 = (SPRITEOFFSET16(6,2));
					}
				} else if(enemies[i].hurt == 1 || enemies[i].hurt == 2) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(6,7);
				} else if(enemies[i].hurt == 3 || enemies[i].hurt == 4) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(6,9);
				} else if(enemies[i].hurt == 5 || enemies[i].hurt == 6) {
					shadowOAM[i + ENM].attr2 = SPRITEOFFSET16(6,11);
				}
			}
		} else if ((!(enemies[i].active) && !(enemies[i].hide)) || enemies[i].hurt == 7) {
			shadowOAM[i+ENM].attr0 = ATTR0_HIDE;
			enemies[i].hide = 1;
			enemies[i].hurt = 0;
			if(enemies[i].hit) {
				enemies[i].dead = 1;
			} 
		}

		//this makes the enemies bounce off the walls and move
		if(enemies[i].active && !enemies[i].hurt) {

			//this gets the enemies to follow the player
			if((enemies[i].col + enemies[i].width) < player.col) {
				
				if(enemies[i].cd < 0) {
					enemies[i].cd = -enemies[i].cd;
				}
				
			} else if (enemies[i].col > (player.col + player.width)) {
				if(enemies[i].cd > 0) {
					enemies[i].cd = -enemies[i].cd;
				}
			}
			//keeps the enemeies on the screen
			if(enemies[i].col < 1) {
					enemies[i].col = 1;
			} else if (enemies[i].col > 240 - enemies[i].width) {
				enemies[i].col = 240 - enemies[i].width;
			}
			enemies[i].col += enemies[i].cd;

			//animates the enemies
			if((!(timer % 15))) {
				if(enemies[i].spriteAttr == LEFT) {
					enemies[i].spriteAttr = RIGHT;
				} else {
					enemies[i].spriteAttr = LEFT;
				}
			}
		}
	}

	//goes through the enemies and the bullets to see if the enemies have been hit
	//if they are incremet score
	for(int i = 0; i < NUMBULLETS; i++) {
		for (int j = 0; j<NUMENEMIES; j++) {
			if(bullets[i].active && !bullets[i].hurt && enemies[j].active && !enemies[j].hurt) {
				int collisionCheck = genericCollision(
					bullets[i].row, bullets[i].col, bullets[i].width, bullets[i].height,
					enemies[j].row + enemies[j].rd, enemies[j].col + enemies[j].cd, enemies[j].width, enemies[j].height);
				if(collisionCheck != -1) {
					bullets[i].hurt = 1;
					enemies[j].hurt = 1;
					enemies[j].hit = 1;
					score++;
				}
			}
		}
	}

	for (int j = 0; j < NUMENEMIES; j++) {
		if(level == 1 && (enemies[j].hurt > 0)) {
			shadowOAM[j + ENM].attr0 = enemies[j].row | ATTR0_NORMAL;
		}
		if(enemies[j].hurt > 0 && enemies[j].hurt < 7) {
			enemies[j].hurt++;
		} else if(enemies[j].hurt == 7) {
			enemiesLeft--;
			enemies[j].active = 0;
			//enemies[j].dead = 1;
		}
	}
	//goes through the enemies and sees if they've hit the player
	//if they have then currently they can't hit the player again
	//also decrease the lives
	//only does this if the player isn't invincible
	if(!player.invincible) {
		for(int i = 0; i < NUMENEMIES; i++) {
			if(enemies[i].active && !(enemies[i].hitplayer) && !enemies[i].hurt) {
				int collisionCheck = genericCollision(
					SHIFTDOWN(player.row), player.col, player.width, player.height,
					enemies[i].row + enemies[i].rd, enemies[i].col + enemies[i].cd, enemies[i].width, enemies[i].height);
				if(collisionCheck != -1) {
					player.livesLost++;
					player.hurt = 1;
					enemies[i].hitplayer = 1;
					//enemies[i].active = 0;
					enemies[i].hurt = 1;
					enemies[i].hit = 1;
					//enemiesLeft--;
					playSoundB(LeftHook, LEFTHOOKLEN, LEFTHOOKFREQ, 0);
				}
			}
		}
	}

	if(player.livesLost > lives) {
		player.dead = 1;
	}

	//creates new enemies based on a timer
	//starts out with the first enemy and doesn't spawn others until the first one is gone
	//this gives the player a better feel for the game before it gets difficult
	int columns[] = {20, 200};
	timer++;
	if(enemiesLeft == NUMENEMIES) {
		if(!(timer%100)) {
			timer = 0;
			enemies[0].active = 1;
			enemies[0].hide = 0;
			enemies[0].used = 1;
			enemies[0].hurt = 0;
			enemies[0].dead = 0;
		}
	} else {
		if(!(timer % 30)) {
			timer = 0;
			for(int i = 0; i < NUMENEMIES; i++) {
				if(!enemies[i].used) {
					enemies[i].col = columns[rand()%(sizeof(columns)/sizeof(columns[0]))];
					enemies[i].active = 1;
					enemies[i].hide = 0;
					enemies[i].used = 1;
					enemies[i].hurt = 0;
					enemies[i].dead = 0;
					break;
				}
			}
		}
	}
}

//updates the bullets
void updateBullets() {
	//goes through bullets and puts them into shadowOAM
	//puts size, where they are, and where on sprite sheet
	for(int i = 0; i<NUMBULLETS; i++) {
		//only shows the bullets if they are active and not hidden
		if(bullets[i].active && !(bullets[i].hide)) {
			shadowOAM[i+BLTS].attr0 = bullets[i].row;
			shadowOAM[i+BLTS].attr1 = ATTR1_SIZE8 | bullets[i].col;
			if(!bullets[i].hurt) {
				shadowOAM[i+BLTS].attr2 = SPRITEOFFSET16(0,4);
			} else if (bullets[i].hurt == 1 || bullets[i].hurt == 2) {
				shadowOAM[i+BLTS].attr2 = SPRITEOFFSET16(0,6);
			} else if (bullets[i].hurt == 3 || bullets[i].hurt == 4) {
				shadowOAM[i+BLTS].attr2 = SPRITEOFFSET16(0,7);
			} else if (bullets[i].hurt == 5 || bullets[i].hurt == 6) {
				shadowOAM[i+BLTS].attr2 = SPRITEOFFSET16(0,8);
			}
		//if bullets become not active, sets them to be hidden
		} else if ((!(bullets[i].active) && !(bullets[i].hide)) || bullets[i].hurt == 7) {
			shadowOAM[i+BLTS].attr0 = ATTR0_HIDE;
			bullets[i].hide = 1;
		}

		//updates the row and col of the bullets and pools them
		if(bullets[i].active) {
			if(bullets[i].hurt > 0 && bullets[i].hurt < 7) {
				bullets[i].hurt++;
			} else if(bullets[i].hurt == 7) {
				bullets[i].active = 0;
			} else {
				if(bullets[i].way == RIGHT) {
					bullets[i].col += bullets[i].cd;
				} else {
					bullets[i].col -= bullets[i].cd;
				}
				if(bullets[i].col < 0 || bullets[i].col > 240) {
					bullets[i].active = 0;
					bullets[i].row = SHIFTDOWN((player.row)) + 16;
					bullets[i].col = player.col;
				}
			}
		}
	}
}

//updates the player if they're at start
void updatePlayerStart() {
	shadowOAM[PLYR].attr0 = (SHIFTDOWN(player.row)) | ATTR0_TALL | ATTR0_NORMAL;	
	shadowOAM[PLYR].attr1 = (COLMASK & player.col) | ATTR1_SIZE32;
	if(player.invincible) {
		shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, (player.spriteAttr * 2) + 10);
	} else {
		shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, player.spriteAttr * 2);
	}

	//updates the lives and score
	updateLives();
	updateScore();

	//updates the player
	//made it equal to hOff in order to scroll the background
	hOff = updatePlayerMoveStart(&player, hOff);

	//checks when you hit A to fire a bullets
	timeSinceLast++;
	if(BUTTON_PRESSED(BUTTON_A)) {
		if((timeSinceLast) > 15) {
			//resets timeSinceLast
			timeSinceLast = 0;
			//sets a nonactive bullet to active
			for(int i = 0; i < NUMBULLETS; i++) {
				if(!bullets[i].active) {
					bullets[i].active = 1;
					bullets[i].hide = 0;
					bullets[i].hurt = 0;
					bullets[i].way = player.spriteAttr;
					if(bullets[i].way == LEFT) {
						bullets[i].col = player.col;
					} else {
						bullets[i].col = player.col + 4;
					}
					bullets[i].row = SHIFTDOWN(player.row) + 16;
					//plays a shooting sound whenever you shoot - doesn't loop
					playSoundB(ShootingSound, SHOOTINGSOUNDLEN, SHOOTINGSOUNDFREQ, 0);
					break;
				}
			}
		}
	}
}

//updates the player if they've defeated the enemies
void updatePlayerNextLevel() {
	//shadowOam the player
	//changes the player to show when you've been hit by the enemies or the electric field
	shadowOAM[PLYR].attr0 = (SHIFTDOWN(player.row)) | ATTR0_TALL;	
	shadowOAM[PLYR].attr1 = (COLMASK & player.col) | ATTR1_SIZE32;
	if(player.invincible) {
		shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, (player.spriteAttr * 2) + 10);
	} else {
		if(player.livesLost == 0) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, player.spriteAttr * 2);
		} else if (player.livesLost == 1) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, player.spriteAttr * 2);
		} else if(player.livesLost == 2) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, (player.spriteAttr * 2) + 4);
		} else if(player.livesLost == 3) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, (player.spriteAttr * 2) + 8);
		}
	}

	//updates the lives and score
	updateLives();
	updateScore();

	//updates the player
	//made it equal to hOff in order to scroll the background
	if(level == 0) {
		hOff = updatePlayerMoveNextLevel(&player, hOff);
	} else if (level == 1) {
		hOff = updatePlayerNextLevel2(&player, hOff);
	} else if (level == 2) {
		hOff = updatePlayerEnd(&player, hOff);
	}

	//checks when you hit A to fire a bullets
	timeSinceLast++;
	if(BUTTON_PRESSED(BUTTON_A)) {
		if((timeSinceLast) > 15) {
			//resets timeSinceLast
			timeSinceLast = 0;
			//sets a nonactive bullet to active
			for(int i = 0; i < NUMBULLETS; i++) {
				if(!bullets[i].active) {
					bullets[i].active = 1;
					bullets[i].hide = 0;
					bullets[i].hurt = 0;
					bullets[i].way = player.spriteAttr;
					if(bullets[i].way == LEFT) {
						bullets[i].col = player.col;
					} else {
						bullets[i].col = player.col + 4;
					}
					bullets[i].row = SHIFTDOWN(player.row) + 16;
					//plays a shooting sound whenever you shoot - doesn't loop
					playSoundB(ShootingSound, SHOOTINGSOUNDLEN, SHOOTINGSOUNDFREQ, 0);
					break;
				}
			}
		}
	}
}

//this updates the player for the game
//I needed a different way to update the player because the collision map will be diffent
//it's basically the same as the start screen one
//the camera doesn't pan because it's not really necissary for this
void updatePlayerGame() {
	//shadowOam the player
	//changes the player to show when you've been hit by the enemies or the electric field
	shadowOAM[PLYR].attr0 = SHIFTDOWN(player.row) | ATTR0_TALL;	
	shadowOAM[PLYR].attr1 = player.col | ATTR1_SIZE32;
	if(player.invincible) {
		shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, (player.spriteAttr * 2) + 10);
	} else {
		if(player.livesLost == 0) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(0, player.spriteAttr * 2);
		} else if (player.livesLost == 1) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, player.spriteAttr * 2);
		} else if(player.livesLost == 2) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, (player.spriteAttr * 2) + 4);
		} else if(player.livesLost == 3) {
			shadowOAM[PLYR].attr2 = SPRITEOFFSET16(19, (player.spriteAttr * 2) + 8);
		}
	}
	//updates everything
	if(level == 0) {
		updatePlayerMoveGame(&player);
	} else if (level == 1) {
		updatePlayerMoveLevel2(&player);
	} else if(level == 2) {
		updatePlayerMoveBoss(&player);
	}
	
	updateLives();
	updateScore();

	timeSinceLast++;
	if(BUTTON_PRESSED(BUTTON_A)) {
		if((timeSinceLast) > 15) {
			//resets timeSinceLast
			timeSinceLast = 0;
			//sets a nonactive bullet to active
			for(int i = 0; i < NUMBULLETS; i++) {
				if(!bullets[i].active) {
					bullets[i].active = 1;
					bullets[i].hide = 0;
					bullets[i].hurt = 0;
					bullets[i].way = player.spriteAttr;
					if(bullets[i].way == LEFT) {
						bullets[i].col = player.col;
					} else {
						bullets[i].col = player.col + 4;
					}
					bullets[i].row = SHIFTDOWN(player.row) + 16;
					playSoundB(ShootingSound, SHOOTINGSOUNDLEN, SHOOTINGSOUNDFREQ, 0);
					break;
				}
			}
		}
	}

	if(player.livesLost > lives) {
		player.dead = 1;
	}
}

//creates a player
void initializePlayer() {
	DMANow(3, SpritesTiles, &CHARBLOCKBASE[4], SpritesTilesLen/2);
    DMANow(3, SpritesPal, SPRITE_PALETTE, 16);
    hideSprites();

    lives = 3;
    score = 0;

    hOff = 0;

    player.grounded = 1;
    player.height = 32;
	player.width = 16;
	player.dead = 0;
	player.livesLost = 0;
	player.hit = 0;
	player.spriteAttr = RIGHT;
	player.row = SHIFTUP(100);
    player.col = 30;
	player.worldCol = player.col + hOff;
	player.hurt = 0;

    player.rdel = 0;
    player.cdel = 2;
    player.racc = 120;

    player.maxHSpeed = SHIFTUP(3);
    player.maxVSpeed = SHIFTUP(8);
}

//creates a player
void initializePlayerGame() {
	DMANow(3, SpritesTiles, &CHARBLOCKBASE[4], SpritesTilesLen/2);
    DMANow(3, SpritesPal, SPRITE_PALETTE, 16);
    hideSprites();

    lives = 3;
    score = 0;

    hOff = 0;

    player.grounded = 1;
    player.height = 32;
	player.width = 16;
	player.dead = 0;
	player.hit = 0;
	player.spriteAttr = RIGHT;
	player.row = SHIFTUP(10);
    player.col = 100;
	player.hurt = 0;

    player.rdel = 0;
    player.cdel = 2;
    player.racc = 120;

    player.maxHSpeed = SHIFTUP(3);
    player.maxVSpeed = SHIFTUP(8);
}

//initializes player for next level
void initializePlayerLevelTwo() {

	DMANow(3, SpritesTiles, &CHARBLOCKBASE[4], SpritesTilesLen/2);
    DMANow(3, SpritesPal, SPRITE_PALETTE, 16);
    hideSprites();
    player.spriteAttr = RIGHT;
    player.row = SHIFTUP(10);
    player.col = 100;
}

//initializes the player for the next level
void initializePlayerNextLevel() {
    hOff = 0;
	player.worldCol = player.col + hOff;
}

//creates the cheat
void initializeCheat() {
	cheat.height = 16;
	cheat.width = 8;
	cheat.row = 140;
	cheat.worldCol = 450;
	cheat.active = 1;
	cheat.hide = 0;
}

//creates the life
void initializeLife() {
	life.height = 16;
	life.width = 8;
	life.row = 49;
	life.worldCol = 370;
	life.active = 1;
	life.hide = 0;
}

//creates barriers
//these are the electric fields
void initializeBarrier() {
	barrier1.height = 64;
	barrier1.width = 10;
	barrier1.row = 94;
	barrier1.col = 2;
	barrier1.active = 1;
	barrier1.hide = 0;

	barrier2.height = 64;
	barrier2.width = 10;
	barrier2.row = 94; 
	barrier2.col = 230;
	barrier2.active = 1;
	barrier2.hide = 0;
}

void initializeBoss() {
	boss.width = 64;
	boss.height = 64;
	boss.cd = 1;
	boss.row = 16;
	boss.col = 0;
	boss.spriteAttr = LEFT;
	boss.active = 1;
	boss.used = 0;
	boss.hit = 0;
	boss.hitplayer = 0;
}

void initializeBossEnemies() {
	bossEnemies[0].width = 16;
	bossEnemies[0].height = 16;
	bossEnemies[0].cd = 1;
	bossEnemies[0].row = 80;
	bossEnemies[0].col = 10;
	bossEnemies[0].spriteAttr = RIGHT;
	bossEnemies[0].active = 0;
	bossEnemies[0].used = 0;
	bossEnemies[0].hit = 0;
	bossEnemies[0].hitplayer = 0;
	bossEnemies[0].hurt = 0;

	bossEnemies[1].width = 16;
	bossEnemies[1].height = 16;
	bossEnemies[1].cd = 1;
	bossEnemies[1].row = 80;
	bossEnemies[1].col = 30;
	bossEnemies[1].spriteAttr = RIGHT;
	bossEnemies[1].active = 0;
	bossEnemies[1].used = 0;
	bossEnemies[1].hit = 0;
	bossEnemies[1].hitplayer = 0;
	bossEnemies[1].hurt = 0;

	bossEnemies[2].width = 16;
	bossEnemies[2].height = 16;
	bossEnemies[2].cd = 1;
	bossEnemies[2].row = 80;
	bossEnemies[2].col = 50;
	bossEnemies[2].spriteAttr = RIGHT;
	bossEnemies[2].active = 0;
	bossEnemies[2].used = 0;
	bossEnemies[2].hit = 0;
	bossEnemies[2].hitplayer = 0;
	bossEnemies[2].hurt = 0;
}

//creates the bullets
void initializeBullets() {
	bullets[0].width = 6;
	bullets[0].height = 6;
	bullets[0].cd = 3;
	bullets[0].row = SHIFTDOWN(player.row) + 16;
	bullets[0].col = player.col;
	bullets[0].active = 0;
	bullets[0].hide = 0;
	bullets[0].hurt = 0;

	//sets all the bullets
	for(int i = 1; i < NUMBULLETS; i++) {
		bullets[i] = bullets[0];
	}
}

//creates the enemies
void initializeEnemies() {
	enemies[0].width = 16;
	enemies[0].height = 16;
	enemies[0].cd = 1;
	enemies[0].row = 142;
	enemies[0].col = 200;
	enemies[0].spriteAttr = LEFT;
	enemies[0].active = 0;
	enemies[0].used = 0;
	enemies[0].hit = 0;
	enemies[0].hitplayer = 0;
	enemies[0].hurt = 0;
	enemies[0].dead = 0;

	for(int i = 1; i < NUMENEMIES; i++) {
		enemies[i] = enemies[0];
	}
}

//creates the enemies for level 2
void initializeEnemiesLevel2() {
	enemies[0].width = 16;
	enemies[0].height = 16;
	enemies[0].cd = 1;
	enemies[0].row = 142;
	enemies[0].col = 20;
	enemies[0].spriteAttr = RIGHT;
	enemies[0].active = 0;
	enemies[0].used = 0;
	enemies[0].hit = 0;
	enemies[0].hitplayer = 0;
	enemies[0].hurt = 0;
	enemies[0].dead = 0;

	for(int i = 1; i < NUMENEMIES; i++) {
		enemies[i] = enemies[0];
	}
}

//updates the score and uses sprites to display it
void updateScore() {
	if(level == 2) {
		shadowOAM[BSSCORE].attr0 = 2 | ATTR0_WIDE;
		shadowOAM[BSSCORE].attr1 = ATTR1_SIZE32 | 106;
		shadowOAM[BSSCORE].attr2 = SPRITEOFFSET16(8, 6);

		for(int i = 0; i < 10; i++) {
			if(i >= boss.hit) {
				shadowOAM[i + SCORE].attr0 = 2;
				shadowOAM[i+SCORE].attr1 = ATTR1_SIZE8 | (146 + ((i - 1) * 8));
				shadowOAM[i+SCORE].attr2 = SPRITEOFFSET16(27, 1);
			} else {
				shadowOAM[i+SCORE].attr2 = SPRITEOFFSET16(27, 3);
			}
		}
		shadowOAM[BSSCORE + 1].attr0 = 2;
		shadowOAM[BSSCORE + 1].attr1 = ATTR1_SIZE8 | 130;
		shadowOAM[BSSCORE + 1].attr2 = SPRITEOFFSET16(27, 0);
		shadowOAM[BSSCORE + 2].attr0 = 2;
		shadowOAM[BSSCORE + 2].attr1 = ATTR1_SIZE8 | 218;
		shadowOAM[BSSCORE + 2].attr2 = SPRITEOFFSET16(27, 2);
	} else {
		shadowOAM[SCORE].attr0 = 2 | ATTR0_WIDE;
		shadowOAM[SCORE].attr1 = ATTR1_SIZE32 | 106;
		shadowOAM[SCORE].attr2 = SPRITEOFFSET16(8, 0);
		
		for(int i = 1; i < NUMENEMIES + 1; i++) {
			if(i <= enemiesLeft) {
				shadowOAM[i+SCORE].attr0 = 2;
				shadowOAM[i+SCORE].attr1 = ATTR1_SIZE8 | (138 + ((i - 1) * 10));
				if(level == 0) {
					shadowOAM[i+SCORE].attr2 = SPRITEOFFSET16(5, 4);
				} else if (level == 1) {
					shadowOAM[i+SCORE].attr2 = SPRITEOFFSET16(7, 4);
				}
			} else {
				shadowOAM[i + SCORE].attr0 = ATTR0_HIDE;
			}
		}
	}
}

//updates the lives and displays them with sprites
void updateLives() {
	//this shows the battery incrementally running out
	for(int i = 0; i < lives; i++) {
		if(i == 0) {
			if(player.livesLost == 3) {
				shadowOAM[LVS].attr0 = 2;
				shadowOAM[LVS].attr1 = (13) | ATTR1_SIZE8;
				shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(25, 1);
			} else {
				shadowOAM[LVS].attr0 = 2;
				shadowOAM[LVS].attr1 = (13) | ATTR1_SIZE8;
				if(player.invincible) {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(1, 5);
				} else {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(0, 5);
				}
			}
		} else if(i == 1) {
			if(player.livesLost == 2 || player.livesLost == 1) {
				shadowOAM[LVS + i].attr0 = 2;
				shadowOAM[LVS + i].attr1 = (13+ 8) | ATTR1_SIZE8;
				shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(25, 1);
			} else {
				shadowOAM[LVS + i].attr0 = 2;
				shadowOAM[LVS + i].attr1 = (13 + 8) | ATTR1_SIZE8;
				if(player.invincible) {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(1, 5);
				} else {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(0, 5);
				}
			}
		} else if(i == 2) {
			if(player.livesLost == 1 || player.livesLost == 2 || player.livesLost == 3) {
				shadowOAM[LVS + i].attr0 = 2;
				shadowOAM[LVS + i].attr1 = (13 + 16) | ATTR1_SIZE8;
				shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(25, 1);
			} else {
				shadowOAM[LVS + i].attr0 = 2;
				shadowOAM[LVS + i].attr1 = (13 + 16) | ATTR1_SIZE8;
				if(player.invincible) {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(1, 5);
				} else {
					shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(0, 5);
				}
			}
		}

		// if (i < (lives - player.livesLost)) {
		// 	shadowOAM[i + LVS].attr0 = 2;
		// 	shadowOAM[i + LVS].attr1 = (13 + (i * 8)) | ATTR1_SIZE8;
		// 	if(player.invincible) {
		// 		shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(1, 5);
		// 	} else {
		// 		shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(0, 5);
		// 	}
		// } else {
		// 	shadowOAM[i + LVS].attr2 = SPRITEOFFSET16(25, 1);
		// }
	}

	// for(int j = 0; j < player.livesLost; j++) {
	// 	shadowOAM[j + LVS].attr2 = SPRITEOFFSET16(25, 1);
	// }

	//this has to show the ends of the battery
	shadowOAM[LVS2].attr0 = 2;
	shadowOAM[LVS2].attr1 = 5 | ATTR1_SIZE8;
	if(!player.invincible) {	
		shadowOAM[LVS2].attr2 = SPRITEOFFSET16(25, 0);
	} else {
		shadowOAM[LVS2].attr2 = SPRITEOFFSET16(26, 0);
	}
	shadowOAM[LVS2 + 1].attr0 = 2;
	shadowOAM[LVS2 + 1].attr1 = 37 | ATTR1_SIZE8;
	shadowOAM[LVS2 + 1].attr2 = SPRITEOFFSET16(25, 2);
}

//updates the cheat
void updateCheat() {
	if(cheat.active) {
		shadowOAM[CHT].attr0 = cheat.row | ATTR0_TALL;
		shadowOAM[CHT].attr1 = (cheat.col & COLMASK) | ATTR1_SIZE16;
		shadowOAM[CHT].attr2 = SPRITEOFFSET16(2, 4);
	} else {
		shadowOAM[CHT].attr0 = ATTR0_HIDE;
	}

	//checks to see if the player got the cheat and changes the appropriate settings
	if(cheat.active) {
		int collisionCheck = genericCollision(
			SHIFTDOWN(player.row), player.col, player.width, player.height,
			cheat.row, cheat.col, cheat.width, cheat.height);
		if(collisionCheck != -1) {
			player.invincible = 1;
			cheat.hitplayer = 1;
			cheat.active = 0;
			playSoundB(getLife, GETLIFELEN, GETLIFEFREQ, 0);
		}
	}
}

//updates the life
void updateLife() {
	if(life.active) {
		shadowOAM[LF].attr0 = life.row | ATTR0_TALL;
		shadowOAM[LF].attr1 = (life.col & COLMASK) | ATTR1_SIZE16;
		shadowOAM[LF].attr2 = SPRITEOFFSET16(2, 5);
	} else {
		shadowOAM[LF].attr0 = ATTR0_HIDE;
	}

	//checks to see if the player got a life and then changes the lives to increase one
	if(life.active) {
		int collisionCheck = genericCollision(
			SHIFTDOWN(player.row), player.col, player.width, player.height,
			life.row, life.col, life.width, life.height);
		if(collisionCheck != -1) {
			if(player.livesLost > 0) {
				player.livesLost--;
			}
			life.hitplayer = 1;
			life.active = 0;
			playSoundB(getLife, GETLIFELEN, GETLIFEFREQ, 0);
		}
	}
}

//updates the electric fields
void updateBarrier() {
	//annimates them
	bartimer2++;
	if(!(bartimer2%20)) {
		if(barrier1.spriteAttr == LEFT) {
			barrier1.spriteAttr = RIGHT;
		} else {
			barrier1.spriteAttr = LEFT;
		}
	}

	//sets the barriers in the shadow oam
	//there are two - one on each side
	if(barrier1.active) {
		shadowOAM[BR].attr0 = barrier1.row | ATTR0_SQUARE;
		shadowOAM[BR].attr1 = barrier1.col | ATTR1_SIZE64;
		if(barrier1.spriteAttr == LEFT) {
			shadowOAM[BR].attr2 = SPRITEOFFSET16(0, 15);
		} else {
			shadowOAM[BR].attr2 = SPRITEOFFSET16(8, 19);
		}
	} else {
		shadowOAM[BR].attr0 = ATTR0_HIDE;
	}

	if(barrier2.active) {
		shadowOAM[BR + 1].attr0 = barrier2.row | ATTR0_SQUARE;
		shadowOAM[BR + 1].attr1 = barrier2.col | ATTR1_SIZE64;
		if(barrier1.spriteAttr == RIGHT) {
			shadowOAM[BR + 1].attr2 = SPRITEOFFSET16(0, 15);
		} else {
			shadowOAM[BR + 1].attr2 = SPRITEOFFSET16(8, 19);
		}
	} else {
		shadowOAM[BR + 1].attr0 = ATTR0_HIDE;
	}
	//checks collision with the barrier and the player
	if(!player.invincible) {
		if(bartimer == 40) {
			bartimer = 0;
		} else if (bartimer > 0) {
			bartimer++;
		}

		if(barrier1.active && bartimer == 0) {
			int collisionCheck = genericCollision(
				SHIFTDOWN(player.row), player.col, player.width, player.height,
				barrier1.row, barrier1.col, barrier1.width, barrier1.height);
			if(collisionCheck != -1) {
				bartimer++;
				playSoundB(electricshock, ELECTRICSHOCKLEN, ELECTRICSHOCKFREQ, 0);
				player.livesLost++;
				player.col += 20;
				player.hurt = 1;
			}
		}
		if(barrier2.active && bartimer == 0) {
			int collisionCheck = genericCollision(
				SHIFTDOWN(player.row), player.col, player.width, player.height,
				barrier2.row, barrier2.col, barrier2.width, barrier2.height);
			if(collisionCheck != -1) {
				bartimer++;
				player.livesLost++;
				player.col -= 20;
				player.hurt = 1;
				playSoundB(electricshock, ELECTRICSHOCKLEN, ELECTRICSHOCKFREQ, 0);
			}
		}
	}

	for(int i = 0; i < NUMBULLETS; i++) {
		if(bullets[i].active && !bullets[i].hurt && barrier1.active) {
			int collisionCheck = genericCollision(
				bullets[i].row, bullets[i].col, bullets[i].width, bullets[i].height,
				barrier1.row, barrier1.col, barrier1.width, barrier1.height);
			if(collisionCheck != -1) {
				bullets[i].hurt = 1;
			}
		}
		if(bullets[i].active && !bullets[i].hurt && barrier2.active) {
			int collisionCheck = genericCollision(
				bullets[i].row, bullets[i].col, bullets[i].width, bullets[i].height,
				barrier2.row, barrier2.col, barrier2.width, barrier2.height);
			if(collisionCheck != -1) {
				bullets[i].hurt = 1;
			}
		}
	}
}

//hides the sprites
void hideSprites() {
    for(int i = 0; i < 128; i++) {
    	shadowOAM[i].attr0 = ATTR0_HIDE;
    }
}