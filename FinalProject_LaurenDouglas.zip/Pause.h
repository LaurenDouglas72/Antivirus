
//{{BLOCK(Pause)

//======================================================================
//
//	Pause, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 188 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 6016 + 4096 = 10624
//
//	Time-stamp: 2017-04-11, 14:50:38
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSE_H
#define GRIT_PAUSE_H

#define PauseTilesLen 6016
extern const unsigned short PauseTiles[3008];

#define PauseMapLen 4096
extern const unsigned short PauseMap[2048];

#define PausePalLen 512
extern const unsigned short PausePal[256];

#endif // GRIT_PAUSE_H

//}}BLOCK(Pause)
