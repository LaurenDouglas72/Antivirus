
//{{BLOCK(Level2BgMAP)

//======================================================================
//
//	Level2BgMAP, 512x160@16, 
//	+ bitmap not compressed
//	Total size: 163840 = 163840
//
//	Time-stamp: 2017-04-12, 17:29:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2BGMAP_H
#define GRIT_LEVEL2BGMAP_H

#define Level2BgMAPBitmapLen 163840
extern const unsigned short Level2BgMAPBitmap[81920];

#endif // GRIT_LEVEL2BGMAP_H

//}}BLOCK(Level2BgMAP)
