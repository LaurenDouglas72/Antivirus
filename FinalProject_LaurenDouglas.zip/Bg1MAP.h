
//{{BLOCK(Bg1MAP)

//======================================================================
//
//	Bg1MAP, 512x160@16, 
//	+ bitmap not compressed
//	Total size: 163840 = 163840
//
//	Time-stamp: 2017-04-10, 19:18:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BG1MAP_H
#define GRIT_BG1MAP_H

#define Bg1MAPBitmapLen 163840
extern const unsigned short Bg1MAPBitmap[81920];

#endif // GRIT_BG1MAP_H

//}}BLOCK(Bg1MAP)
