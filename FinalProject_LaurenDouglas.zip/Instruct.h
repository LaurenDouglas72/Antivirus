
//{{BLOCK(Instruct)

//======================================================================
//
//	Instruct, 256x512@4, 
//	+ palette 256 entries, not compressed
//	+ 977 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x64 
//	Total size: 512 + 31264 + 4096 = 35872
//
//	Time-stamp: 2017-04-08, 19:32:10
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_INSTRUCT_H
#define GRIT_INSTRUCT_H

#define InstructTilesLen 31264
extern const unsigned short InstructTiles[15632];

#define InstructMapLen 4096
extern const unsigned short InstructMap[2048];

#define InstructPalLen 512
extern const unsigned short InstructPal[256];

#endif // GRIT_INSTRUCT_H

//}}BLOCK(Instruct)
