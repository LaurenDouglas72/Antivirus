#include "myLib.h"

unsigned short *videoBuffer = (u16 *)0x6000000;

unsigned short *frontBuffer = (u16 *)0x6000000;
unsigned short *backBuffer =  (u16 *)0x600A000;

DMA *dma = (DMA *)0x40000B0;

void loadPalette(const unsigned short* palette)
{
	DMANow(3, (unsigned short*)palette, PALETTE, 256);
}


void DMANow(int channel, volatile const void* source, volatile void* destination, unsigned int control)
{
	dma[channel].src = source;
	dma[channel].dst = destination;
	dma[channel].cnt = DMA_ON | control;
}

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}


void flipPage()
{
    if(REG_DISPCTL & BACKBUFFER)
    {
        REG_DISPCTL &= ~BACKBUFFER;
        videoBuffer = backBuffer;
    }
    else
    {
        REG_DISPCTL |= BACKBUFFER;
        videoBuffer = frontBuffer;
    }
}

//checks for collision
//return 0 for top collision, 1 for bottom, 2 for left, 3 for right
int genericCollision(int r1, int c1, int w1, int h1, int r2, int c2, int w2, int h2) {

    //return 0 for top collision
    //2nd box is above 1st box and in line with the column
    if((r1 <= r2+h2 && r1 >= r2) && (c1 < c2+w2 && c1+w1 > c2)) {
        return 0;
    }

    //return 1 for bottom collision
    //2nd box is below 1st box and in line with column
    if((r1+h1 >= r2 && r1+h1 <= r2+h2) && (c1 < c2+w2 && c1+w1 > c2)) {
        return 1;
    }

    //return 2 for left collision
    //2nd box is left of 1st box and rows are lined up
    if((c1 <= c2+w2 && c1 >= c2) && (r1 < r2+h2 && r1+h1 > r2)) {
        return 2;
    }

    //return 3 for right collision
    //2nd box is right of 1st box and the rows are lined up
    if ((c1+w1 >= c2 && c1+w1 <= c2+w2) && (r1 < r2+h2 && r1+h1 > r2)) {
        return 3;
    }

    //return -1 for no collision
    return -1;
}

void drawBackgroundImage4(volatile const unsigned short* image) {
    DMANow(3, (unsigned short*)image, videoBuffer, (240*160)/2);
}