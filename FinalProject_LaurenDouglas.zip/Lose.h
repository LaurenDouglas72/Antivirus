
//{{BLOCK(Lose)

//======================================================================
//
//	Lose, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 281 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 8992 + 2048 = 11552
//
//	Time-stamp: 2017-04-10, 10:07:42
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LOSE_H
#define GRIT_LOSE_H

#define LoseTilesLen 8992
extern const unsigned short LoseTiles[4496];

#define LoseMapLen 2048
extern const unsigned short LoseMap[1024];

#define LosePalLen 512
extern const unsigned short LosePal[256];

#endif // GRIT_LOSE_H

//}}BLOCK(Lose)
