typedef struct{
    const unsigned char* data;
    //how many samples
    int length;
    //should all be 11025
    int frequency;
    int isPlaying;
    //says if the sound is supposed to loop or not
    int loops;
    //how many vblanks before an iteration
    int duration;
    //used to decide which sound should play and which is more important
    int priority;
    //how many vblanks we are into the sound
    int vbCount;
}SOUND;

void setupSounds();
void playSoundA( const unsigned char* sound, int length, int frequency, int loops);
void playSoundB( const unsigned char* sound, int length, int frequency, int loops);

void setupInterrupts();
void interruptHandler();