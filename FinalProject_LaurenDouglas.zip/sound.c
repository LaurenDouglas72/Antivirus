#include "sound.h"
#include "myLib.h"
#include "main.h"
#include "maintheme.h"
#include "ShootingSound.h"
#include "LeftHook.h"
#include "Roar.h"

//can play 2 sounds simultaneously
SOUND soundA;
SOUND soundB;

//sets up all the sounds for a game
void setupSounds() {
	//overall sound enable flag - this enables sound
    REG_SOUNDCNT_X = SND_ENABLED;
    //high quality sounds
	REG_SOUNDCNT_H = SND_OUTPUT_RATIO_100 |
					//sound A 
                     DSA_OUTPUT_RATIO_100 | 
                     DSA_OUTPUT_TO_BOTH | 
                     //A sound register uses timer 0
                     DSA_TIMER0 | 
                     DSA_FIFO_RESET |
                     //sound B
                     DSB_OUTPUT_RATIO_100 | 
                     DSB_OUTPUT_TO_BOTH | 
                     //B sound register uses timer 1
					 //this is because 
                     DSB_TIMER1 | 
                     DSB_FIFO_RESET;
	//low quality sounds
	//means you can manually code low quality sounds
	//we just turn this off
	REG_SOUNDCNT_L = 0;
}

void playSoundA( const unsigned char* sound, int length, int frequency, int loops) {
        //you can only have two simultaneous sounds playing at the same time
		//so you want to stop the sound that's already playing
		//so stop it by setting the dma 1 to 0
        dma[1].cnt = 0;
		//how many processor ticks  the timer tackes to update
        int ticks = PROCESSOR_CYCLES_PER_SECOND/frequency;
	
		//use DMA 1 for sound
		//puts something into the FIFO and then it will pop it off and put it into the sound
		//DMA_AT_REFRESH and DMA_REPEAT work together so that you don't have to call DMA repeatedly
		//it starts and then keeps going
		//DMA_32 because DMA will automatically puts in 16 bit info and you want 32 bit info bc sound is //characters
		//you could add DMA_SOURCE_INCREMENT to the last argument, but it's DMAs default, so we don't have to
        DMANow(1, sound, REG_FIFO_A, DMA_DESTINATION_FIXED | DMA_AT_REFRESH | DMA_REPEAT | DMA_32);
	
		//we need to use timers
		//we need to clear the timer
		//sound register A is set to timer 0
        REG_TM0CNT = 0;
	
		//needs to know when to update
        REG_TM0D = -ticks;

        //if timer is on it will copy info to FIFO
        REG_TM0CNT = TIMER_ON;

        soundA.isPlaying = 1;
        soundA.data = sound;
        soundA.length = length;
    	soundA.frequency = frequency;
    	soundA.loops = loops;
    	soundA.duration = ((VBLANK_FREQ*length)/frequency);
    	soundA.vbCount = 0;
        
}


void playSoundB( const unsigned char* sound, int length, int frequency, int loops) {

        dma[2].cnt = 0;

        int ticks = PROCESSOR_CYCLES_PER_SECOND/frequency;

        DMANow(2, sound, REG_FIFO_B, DMA_DESTINATION_FIXED | DMA_AT_REFRESH | DMA_REPEAT | DMA_32);

        REG_TM1CNT = 0;
	
        REG_TM1D = -ticks;
        REG_TM1CNT = TIMER_ON;
	
        soundB.isPlaying = 1;
        soundB.data = sound;
        soundB.length = length;
    	soundB.frequency = frequency;
    	soundB.loops = loops;
    	soundB.duration = ((VBLANK_FREQ*length)/frequency);
    	soundB.vbCount = 0;    
}

//sets up the interrupts
void setupInterrupts() {
	//general enable interrupts register - turn on interrupts and start handling them
	//you must disable them and then reable them
	//overall interrupt flag must be turned off if you do ANYTHING with interrupts
	REG_IME = 0;
	//holds the memory address of the interruptHandler function
	//calls interruptHandler for you
	//this expects an unsigned int, so you have to cast it
	//the way to get a pointer to a function is to just write the name of the function
	//so this function gets called every time a vblank happens
	REG_INTERRUPT = (unsigned int)interruptHandler;
	//register interrupt event flag
	//this decides who can interrupt you - which specific interrupts work
	//set vblank interrupt
	//set it so that every time there is a vblank you handle an interrupt
	REG_IE |= INT_VBLANK;
	//this sends vblank interrupts from the display
	REG_DISPSTAT |= INT_VBLANK_ENABLE;
	//turn the general interrupt flag back on
	//what will it do when the interrupts happen?
	REG_IME = 1;
}

//this is called for you using the REG_INTERRUPT flag 
//use interruptHandler to decide if a sound has finished and if it has looped
void interruptHandler() {
	//overall interrupt flag must be turned off if you do ANYTHING with interrupts
	REG_IME = 0;
	//sees if a vblank has happened to see which flag has happened
	if(REG_IF & INT_VBLANK) {
		//check to make sure that the sound is actually playing
		if(soundA.isPlaying) {
			//we know if we are in this if statement that a vblank has happened
			//and that the sound is playing
			//update how many vblanks have occurred
			soundA.vbCount++;
			//check the duration because it is how many vbcouts have occured
			//if the vbcount is greater than the duration then do something with the sound
			//either reloop it or turn it off
			if(soundA.vbCount > soundA.duration) {
				//check to see if it supposed to loop
				//if it is supposed to loop then recall it by saying playSoundA
				//you could also say 1 for soundA.loops if you know it's supposed to loop
				if(soundA.loops) {
					playSoundA(soundA.data, soundA.length, soundA.frequency, soundA.loops);
					//if it's not supposed to loop then set everything to 0
				} else {
					//stop copying thing into the DMA control
					//you need all of the below to completely stop
					dma[1].cnt = 0;
					soundA.isPlaying = 0;
					REG_TM0CNT = 0;
				}
			}
		} 
		if(soundB.isPlaying) {
			soundB.vbCount++;
			if(soundB.vbCount > soundB.duration) {
				if(soundB.loops) {
					playSoundB(soundB.data, soundB.length, soundB.frequency, soundB.loops);
				} else {
					dma[2].cnt = 0;
					soundB.isPlaying = 0;
					REG_TM1CNT = 0;
				}
			}
		}

		REG_IF = INT_VBLANK; 
	}

	REG_IME = 1;
}