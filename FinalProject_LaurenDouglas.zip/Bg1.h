
//{{BLOCK(Bg1)

//======================================================================
//
//	Bg1, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 254 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 8128 + 4096 = 12736
//
//	Time-stamp: 2017-04-18, 13:33:01
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BG1_H
#define GRIT_BG1_H

#define Bg1TilesLen 8128
extern const unsigned short Bg1Tiles[4064];

#define Bg1MapLen 4096
extern const unsigned short Bg1Map[2048];

#define Bg1PalLen 512
extern const unsigned short Bg1Pal[256];

#endif // GRIT_BG1_H

//}}BLOCK(Bg1)
