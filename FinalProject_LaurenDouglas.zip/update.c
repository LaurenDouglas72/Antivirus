#include "main.h"
#include "myLib.h"
#include "Bg1.h"
#include "Bg1MAP.h"
#include "LevelBgMAP.h"
#include "Level2BgMAP.h"
#include "BossMAP.h"


//used to animate player
enum{RIGHT, LEFT};

//this updates the player as they move in the start screen
int updatePlayerMoveStart(PLAYER * player, int hOff) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw
	int anyInput = 0;

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height - 1) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height - 1);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

   //checks the top of the character to see when it hits black
    if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol, 512)] == BLACK ||
    	Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(Bg1MAPBitmap[OFFSET(i, player->worldCol + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(Bg1MAPBitmap[OFFSET(i, player->worldCol, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol, 512)] != BLACK
	    	&& Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->worldCol; i < (player->worldCol + player->width); i++) {
    	if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 1) {
        player->col = 2;
    }

    if(player->worldCol >= 512 - player->width - 2) {
        player->worldCol = 512 - player->width - 2;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //checks the worldCol and shifts the camera view to follow the player
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		anyInput = 1;
		if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height - 1, player->worldCol + player->width + 1, 512)] == WHITE) {
			if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol + player->width + 1, 512)] == WHITE) {
				if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol + player->width + 1, 512)] == WHITE) {
					if(player->worldCol >= 0) {	
						if(x==0) {
							player->worldCol+=player->cdel;
						}
						if(player->col >= 120 && hOff < (512 - 240)) {
							hOff+=2;
						}
					}
				}
			}
		//if you go into the red part of map then you go to the game bc that's going through the door
		} else if (Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol + player->width + 1, 512)] == RED) {
			goToGamefromStart();
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		anyInput = 1;
		if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row ) + player->height - 1, player->worldCol - 1, 512)] == WHITE) {
			if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol - 1, 512)] == WHITE) {
				if(Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol - 1, 512)] == WHITE) {	
					if(player->worldCol > 0) {	
						if(x==0){
							player->worldCol-=player->cdel;
						}
						if(player->col <= 120 && hOff > 0) {
							hOff-=2;
						}
					}
				}
			}
		} else if (Bg1MAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol - 1, 512)] == RED) {
			goToGamefromStart();
		}
	}
	
	//updates the worldCol and col
	if(anyInput) {
		updateScreenLocations(player, hOff);
	}
	//return hOff in order to update the screen position
	return hOff;
}

//updates the player as they move in the game
void updatePlayerMoveGame(PLAYER * player) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

    //checks the top of the character to see when it hits black
    if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col, 512)] == BLACK ||
    	LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(LevelBgMAPBitmap[OFFSET(i, player->col + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(LevelBgMAPBitmap[OFFSET(i, player->col, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col, 512)] != BLACK
	    	&& LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->col; i < (player->col + player->width); i++) {
    	if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 11) {
        player->col = 11;
    }

    //changed #s for electric fields
    if(player->col >= SCREENWIDTH - player->width - 11) {
        player->col = SCREENWIDTH - player->width - 11;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //moves you right and left
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += player->cdel;
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += -player->cdel;
		}
	}
}

//this updates the player as they move in the start screen
int updatePlayerMoveNextLevel(PLAYER * player, int hOff) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw
	int anyInput = 0;

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height - 1) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height - 1);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

   //checks the top of the character to see when it hits black
    if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol, 512)] == BLACK ||
    	LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(LevelBgMAPBitmap[OFFSET(i, player->worldCol + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(LevelBgMAPBitmap[OFFSET(i, player->worldCol, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol, 512)] != BLACK
	    	&& LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->worldCol; i < (player->worldCol + player->width); i++) {
    	if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 19) {
        player->col = 19;
    }

	//keeps the player on the screen
    if(player->col <= 1) {
        player->col = 2;
    }

    if(player->col >= SCREENWIDTH - player->width - 1) {
        player->col = SCREENWIDTH - player->width - 1;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //checks the worldCol and shifts the camera view to follow the player
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		anyInput = 1;
		if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height - 1, player->worldCol + player->width + 1, 512)] == WHITE) {
			if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol + player->width + 1, 512)] == WHITE) {
				if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol + player->width + 1, 512)] == WHITE) {
					if(player->worldCol >= 0) {	
						if(x == 0) {
							player->worldCol += player->cdel;
						}
						if(player->col >= 120 && hOff < (512 - 240)) {
							hOff+=2;
						}
					}
				}
			}
		//if you go into the red part of map then you go to the game bc that's going through the door
		} else if (LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol + player->width + 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToLevelTwo();
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		anyInput = 1;
		if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row ) + player->height - 1, player->worldCol - 1, 512)] == WHITE) {
			if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol - 1, 512)] == WHITE) {
				if(LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol - 1, 512)] == WHITE) {	
					if(player->worldCol > 0) {	
						if(x==0) { 
							player->worldCol -= player->cdel;
						}
						if(player->col <= 120 && hOff > 0) {
							hOff-=2;
						}
					}
				}
			}
		} else if (LevelBgMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol - 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToLevelTwo();
		}
	}
	
	//updates the worldCol and col
	if(anyInput) {
		updateScreenLocations(player, hOff);
	}
	//return hOff in order to update the screen position
	return hOff;
}

void updatePlayerMoveLevel2(PLAYER *player) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

    //checks the top of the character to see when it hits black
    if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col, 512)] == BLACK ||
    	Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(Level2BgMAPBitmap[OFFSET(i, player->col + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(Level2BgMAPBitmap[OFFSET(i, player->col, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col, 512)] != BLACK
	    	&& Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->col; i < (player->col + player->width); i++) {
    	if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 11) {
        player->col = 11;
    }

    //changed #s for electric fields
    if(player->col >= SCREENWIDTH - player->width - 11) {
        player->col = SCREENWIDTH - player->width - 11;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //moves you right and left
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += player->cdel;
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += -player->cdel;
		}
	}
}

//this updates the player as they move over to level 3
int updatePlayerNextLevel2(PLAYER * player, int hOff) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw
	int anyInput = 0;

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height - 1) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height - 1);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

   //checks the top of the character to see when it hits black
    if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol, 512)] == BLACK ||
    	Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(Level2BgMAPBitmap[OFFSET(i, player->worldCol + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(Level2BgMAPBitmap[OFFSET(i, player->worldCol, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol, 512)] != BLACK
	    	&& Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->worldCol; i < (player->worldCol + player->width); i++) {
    	if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 19) {
        player->col = 19;
    }

	//keeps the player on the screen
    if(player->col <= 1) {
        player->col = 2;
    }

    if(player->col >= SCREENWIDTH - player->width - 1) {
        player->col = SCREENWIDTH - player->width - 1;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //checks the worldCol and shifts the camera view to follow the player
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		anyInput = 1;
		if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height - 1, player->worldCol + player->width + 1, 512)] == WHITE) {
			if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol + player->width + 1, 512)] == WHITE) {
				if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol + player->width + 1, 512)] == WHITE) {
					if(player->worldCol >= 0) {	
						if(x == 0) {
							player->worldCol += player->cdel;
						}
						if(player->col >= 120 && hOff < (512 - 240)) {
							hOff+=2;
						}
					}
				}
			}
		//if you go into the red part of map then you go to the game bc that's going through the door
		} else if (Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol + player->width + 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToBossLevel();
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		anyInput = 1;
		if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row ) + player->height - 1, player->worldCol - 1, 512)] == WHITE) {
			if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol - 1, 512)] == WHITE) {
				if(Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol - 1, 512)] == WHITE) {	
					if(player->worldCol > 0) {	
						if(x==0) { 
							player->worldCol -= player->cdel;
						}
						if(player->col <= 120 && hOff > 0) {
							hOff-=2;
						}
					}
				}
			}
		} else if (Level2BgMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol - 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToBossLevel();
		}
	}
	
	//updates the worldCol and col
	if(anyInput) {
		updateScreenLocations(player, hOff);
	}
	//return hOff in order to update the screen position
	return hOff;
}

void updatePlayerMoveBoss(PLAYER *player) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

    //checks the top of the character to see when it hits black
    if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col, 512)] == BLACK ||
    	BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->col + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(BossMAPBitmap[OFFSET(i, player->col + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(BossMAPBitmap[OFFSET(i, player->col, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col, 512)] != BLACK
	    	&& BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->col + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->col; i < (player->col + player->width); i++) {
    	if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 11) {
        player->col = 11;
    }

    //changed #s for electric fields
    if(player->col >= SCREENWIDTH - player->width - 11) {
        player->col = SCREENWIDTH - player->width - 11;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //moves you right and left
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += player->cdel;
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		//doesn't move character if they are in black at all
		if(x == 0) {
			player->col += -player->cdel;
		}
	}
}

//this updates the player as they move over to level 3
int updatePlayerEnd(PLAYER * player, int hOff) {
	//implements gravity 
	//doesn't do acceleration with the colomn - that's on purpose btw
	int anyInput = 0;

	//only updates player jumping if it's grounded
	if(!player->grounded) {
		player->rdel += player->racc;
		player->row += player->rdel;
	}

	//if player is at the bottom of the screen then stop
	if(SHIFTDOWN(player->row) >= SCREENHEIGHT - player->height - 1) {
        player->row = SHIFTUP(SCREENHEIGHT - player->height - 1);
        player->rdel = 0;
    }
    
    //if player is at the top of the screen then fall
    if(SHIFTDOWN(player->row) <= 0) {
        player->row = SHIFTUP(SHIFTDOWN(player->row) + 2);
        player->rdel = 0;
        player->grounded = 0;
    }

   //checks the top of the character to see when it hits black
    if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol, 512)] == BLACK ||
    	BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 1, player->worldCol + player->width, 512)] == BLACK) {
    		player->row = SHIFTUP(SHIFTDOWN(player->row) + 1);
    		player->rdel = -player->rdel;
    }

    //checks the middle of the player to see if they're moving into the black area at all
    int x = 0;
    for(int i = SHIFTDOWN(player->row); i < (SHIFTDOWN(player->row) + player->height); i++) {
    	if(BossMAPBitmap[OFFSET(i, player->worldCol + player->width, 512)] == BLACK) {
    		x++;
    	} 
    	if(BossMAPBitmap[OFFSET(i, player->worldCol, 512)] == BLACK) {
    		x++;
    	}
    }

    //if what's under you is no longer black then you're not grounded
    if(player->grounded) {
	    if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol, 512)] != BLACK
	    	&& BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height + 1, player->worldCol + player->width, 512)] != BLACK) {
	    	player->grounded = 0;
	    }
	}

	//checks the map and if you are not grounded to make it so that you land on the platforms and don't end up in the middle
    int a = 0;
    for(int i = player->worldCol; i < (player->worldCol + player->width); i++) {
    	if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height, i, 512)] == BLACK) {
    		a++;
    	}
    }
    if(a>0) {
    	player->row = SHIFTUP(SHIFTDOWN(player->row) - 1);
    	player->grounded = 1;
    }

	//keeps the player on the screen
    if(player->col <= 19) {
        player->col = 19;
    }

	//keeps the player on the screen
    if(player->col <= 1) {
        player->col = 2;
    }

    if(player->col >= SCREENWIDTH - player->width - 1) {
        player->col = SCREENWIDTH - player->width - 1;
    }

    //makes you jump 
    if (BUTTON_PRESSED(BUTTON_UP) && player->grounded) {
    	player->grounded = 0;
    	player->rdel = -player->maxVSpeed;
    }

    //checks the worldCol and shifts the camera view to follow the player
	if(BUTTON_HELD(BUTTON_RIGHT)) {
		player->spriteAttr = RIGHT;
		anyInput = 1;
		if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + player->height - 1, player->worldCol + player->width + 1, 512)] == WHITE) {
			if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol + player->width + 1, 512)] == WHITE) {
				if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol + player->width + 1, 512)] == WHITE) {
					if(player->worldCol >= 0) {	
						if(x == 0) {
							player->worldCol += player->cdel;
						}
						if(player->col >= 120 && hOff < (512 - 240)) {
							hOff+=2;
						}
					}
				}
			}
		//if you go into the red part of map then you go to the game bc that's going through the door
		} else if (BossMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol + player->width + 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToWin();
		}
	} else if (BUTTON_HELD(BUTTON_LEFT)) {
		player->spriteAttr = LEFT;
		anyInput = 1;
		if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row ) + player->height - 1, player->worldCol - 1, 512)] == WHITE) {
			if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + 2, player->worldCol - 1, 512)] == WHITE) {
				if(BossMAPBitmap[OFFSET(SHIFTDOWN(player->row) + (player->height / 2), player->worldCol - 1, 512)] == WHITE) {	
					if(player->worldCol > 0) {	
						if(x==0) { 
							player->worldCol -= player->cdel;
						}
						if(player->col <= 120 && hOff > 0) {
							hOff-=2;
						}
					}
				}
			}
		} else if (BossMAPBitmap[OFFSET(SHIFTDOWN(player->row), player->worldCol - 1, 512)] == RED) {
			//player->lastLivesLost = player->livesLost;
			goToBossLevel();
		}
	}
	
	//updates the worldCol and col
	if(anyInput) {
		updateScreenLocations(player, hOff);
	}
	//return hOff in order to update the screen position
	return hOff;
}

//updates the screen locations
void updateScreenLocations(PLAYER * player, int hOff) {
	REG_BG0HOFS = hOff;

	player->col = player->worldCol - hOff;
}