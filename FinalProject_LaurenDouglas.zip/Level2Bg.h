
//{{BLOCK(Level2Bg)

//======================================================================
//
//	Level2Bg, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 176 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 5632 + 4096 = 10240
//
//	Time-stamp: 2017-04-18, 13:44:44
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL2BG_H
#define GRIT_LEVEL2BG_H

#define Level2BgTilesLen 5632
extern const unsigned short Level2BgTiles[2816];

#define Level2BgMapLen 4096
extern const unsigned short Level2BgMap[2048];

#define Level2BgPalLen 512
extern const unsigned short Level2BgPal[256];

#endif // GRIT_LEVEL2BG_H

//}}BLOCK(Level2Bg)
