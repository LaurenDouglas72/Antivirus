int updatePlayerMoveStart(PLAYER * player, int hOff);
void updateScreenLocations(PLAYER * player, int hOff);
void updatePlayerMoveGame(PLAYER * player);
int updatePlayerMoveNextLevel(PLAYER * player, int hOff);
void updatePlayerMoveLevel2(PLAYER *player);
int updatePlayerNextLevel2(PLAYER * player, int hOff);
void updatePlayerMoveBoss(PLAYER *player);
int updatePlayerEnd(PLAYER * player, int hOff);