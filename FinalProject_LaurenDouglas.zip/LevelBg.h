
//{{BLOCK(LevelBg)

//======================================================================
//
//	LevelBg, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 180 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 5760 + 4096 = 10368
//
//	Time-stamp: 2017-04-24, 13:19:44
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVELBG_H
#define GRIT_LEVELBG_H

#define LevelBgTilesLen 5760
extern const unsigned short LevelBgTiles[2880];

#define LevelBgMapLen 4096
extern const unsigned short LevelBgMap[2048];

#define LevelBgPalLen 512
extern const unsigned short LevelBgPal[256];

#endif // GRIT_LEVELBG_H

//}}BLOCK(LevelBg)
